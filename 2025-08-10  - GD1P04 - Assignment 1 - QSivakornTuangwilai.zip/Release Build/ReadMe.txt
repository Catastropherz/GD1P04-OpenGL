Run Assignment1.exe for the program.
